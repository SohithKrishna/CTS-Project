package com.project.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.dto.CustomerListResponseDTO;
import com.project.dto.CustomerRequestDTO;
import com.project.dto.CustomerResponseDTO;
import com.project.exception.CustomerNotFoundException;
import com.project.model.Customer;
import com.project.service.CustomerService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/customer")
@Tag(name = "Customer Controller", description = "This is Customer Controller")
public class CustomerController {

	@Autowired
	CustomerService service;

	@PostMapping("/addCustomer")
	@Operation(summary = "Add a Customer")
	public ResponseEntity<CustomerResponseDTO> addCustomer(@Valid @RequestBody CustomerRequestDTO requestDTO) {
		Customer customer = requestDTO.getCustomer();

		if (customer == null) {
			CustomerResponseDTO dto = new CustomerResponseDTO(null, 400, "Invalid request: customer is missing");
			return ResponseEntity.badRequest().body(dto);
		}

		Customer created = service.createCustomer(customer);

		CustomerResponseDTO dto = new CustomerResponseDTO(created, 200, "Customer Saved Successfully");
		return ResponseEntity.status(HttpStatus.CREATED).body(dto);
	}

	@GetMapping("/viewAllCustomers")
	@Operation(summary = "View All Customers")
	public ResponseEntity<CustomerListResponseDTO> viewAllCustomers() {

		List<Customer> customers = service.viewAllCustomers();

		if (customers.isEmpty()) {
			return ResponseEntity.noContent().build();
		}

		CustomerListResponseDTO dto = new CustomerListResponseDTO();
		dto.setHttpStatusCode(HttpStatus.OK.value());
		dto.setMessage(customers.size() + " Customers fetched");
		dto.setCustomers(customers);

		return ResponseEntity.ok(dto);
	}
	
	@GetMapping("/viewCustomer/{id}")
	@Operation(summary = "View Customer by ID")
	public ResponseEntity<CustomerResponseDTO> f3(@PathVariable(name = "id") Long id) {
		Customer customer = service.findById(id);

		CustomerResponseDTO dto = new CustomerResponseDTO();
		if (customer == null) {
			dto.setHttpStatusCode(HttpStatus.NOT_FOUND.value());
			dto.setCustomer(null);
			dto.setMessage("Customer with id " + id + " Not Found");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(dto);
		}

		dto.setHttpStatusCode(HttpStatus.OK.value());
		dto.setCustomer(customer);
		dto.setMessage("Customer with id " + id + " Found");
		return ResponseEntity.ok(dto);
	}

	@PutMapping("/updateCustomer/{id}")
	@Operation(summary = "Update Customer")
	public ResponseEntity<CustomerResponseDTO> updateCustomer(@PathVariable Long id,
			@Valid @RequestBody CustomerRequestDTO requestDTO) throws CustomerNotFoundException {
		Customer updatedDetails = requestDTO.getCustomer();
		if (updatedDetails == null) {
			return ResponseEntity.badRequest().body(
					new CustomerResponseDTO(null, HttpStatus.BAD_REQUEST.value(), "Customer details are missing"));
		}
		Customer updatedCustomer = service.updateCustomer(id, updatedDetails);
		CustomerResponseDTO dto = new CustomerResponseDTO();
		dto.setHttpStatusCode(HttpStatus.OK.value());
		dto.setCustomer(updatedCustomer);
		dto.setMessage("Customer with id " + id + " Updated Successfully");

		return ResponseEntity.ok(dto);
	}

	@DeleteMapping("/deleteCustomer/{id}")
	@Operation(summary = "Delete Customer")
	public ResponseEntity<CustomerResponseDTO> deleteCustomer(@PathVariable Long id) throws CustomerNotFoundException {
		service.deleteCustomer(id);
		CustomerResponseDTO dto = new CustomerResponseDTO();
		dto.setHttpStatusCode(HttpStatus.OK.value());
		dto.setCustomer(null);
		dto.setMessage("Customer with id " + id + " Deleted Successfully");
		return ResponseEntity.ok(dto);
	}

	@GetMapping("/email/{email}")
	@Operation(summary = "Get Customer by Email")
	public ResponseEntity<CustomerResponseDTO> getCustomerByEmail(@PathVariable String email)
			throws CustomerNotFoundException {
		Customer customer = service.getCustomerByEmail(email);

		CustomerResponseDTO responseDTO = new CustomerResponseDTO();
		responseDTO.setCustomer(customer);
		responseDTO.setHttpStatusCode(200);
		responseDTO.setMessage("Customer fetched successfully");

		return ResponseEntity.ok(responseDTO);
	}

	@GetMapping("/phone/{phone}")
	@Operation(summary = "Get Customer by Phone Number")
	public ResponseEntity<CustomerResponseDTO> getCustomerByPhoneNumber(@PathVariable String phone)
			throws CustomerNotFoundException {
		Customer customer = service.getCustomerByPhoneNumber(phone);

		CustomerResponseDTO responseDTO = new CustomerResponseDTO();
		responseDTO.setCustomer(customer);
		responseDTO.setHttpStatusCode(200);
		responseDTO.setMessage("Customer fetched successfully");

		return ResponseEntity.ok(responseDTO);
	}

}
