package com.project.dto;

import com.project.model.Customer;

public class CustomerResponseDTO {
	
	Customer customer;
	int httpStatusCode;
	String message;
	
	public CustomerResponseDTO(Customer customer, int httpStatusCode, String message) {
		super();
		this.customer = customer;
		this.httpStatusCode = httpStatusCode;
		this.message = message;
	}
	
	public CustomerResponseDTO() {
		super();
	}
	
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public int getHttpStatusCode() {
		return httpStatusCode;
	}
	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
