package com.project.dto;

import com.project.model.Customer;

import jakarta.validation.Valid;

public class CustomerRequestDTO {
	
	@Valid
	Customer customer;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
}
