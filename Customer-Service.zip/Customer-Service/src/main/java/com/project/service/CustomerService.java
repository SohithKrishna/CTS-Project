package com.project.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.db.CustomerRepository;
import com.project.exception.CustomerNotFoundException;
import com.project.model.Customer;

@Service
public class CustomerService {

	@Autowired
	CustomerRepository repo;

	public Customer createCustomer(Customer customer) {
		customer.setCreatedAt(LocalDateTime.now());
		return repo.save(customer);
	}

	public List<Customer> viewAllCustomers() {
		return repo.findAll();
	}
	
	public void deleteCustomer(Long id) throws CustomerNotFoundException {
		Customer existingCustomer = repo.findById(id)
				.orElseThrow(() -> new CustomerNotFoundException("Customer with id " + id + " Not Found"));
		repo.delete(existingCustomer);
	}

	public Customer updateCustomer(Long id, Customer updatedDetails) throws CustomerNotFoundException {
		if (updatedDetails == null) {
			throw new IllegalArgumentException("Customer details are missing");
		}
		
		Customer existingCustomer = repo.findById(id)
				.orElseThrow(() -> new CustomerNotFoundException("Customer with id " + id + " Not Found"));
		existingCustomer.setFirstName(updatedDetails.getFirstName());
		existingCustomer.setLastName(updatedDetails.getLastName());
		existingCustomer.setEmail(updatedDetails.getEmail());
		existingCustomer.setPhone(updatedDetails.getPhone());
		existingCustomer.setAddress(updatedDetails.getAddress());

		return repo.save(existingCustomer);
	}

	public Customer findById(Long id) {
		Optional<Customer> cus = repo.findById(id);
		if (cus.isPresent()) {
			return cus.get();
		}
		return null;
	}

	public Customer getCustomerByEmail(String email) throws CustomerNotFoundException {
		return repo.findByEmail(email)
				.orElseThrow(() -> new CustomerNotFoundException("Customer Not found with email: " + email));
	}

	public Customer getCustomerByPhoneNumber(String phone) throws CustomerNotFoundException {
		return repo.findByPhone(phone)
				.orElseThrow(() -> new CustomerNotFoundException("Customer not found with phone number: " + phone));
	}
}
