package com.project.db;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.project.model.Customer;

@DataJpaTest
public class CustomerRepoTest {

	@Mock
	private CustomerRepository repo;

	@Test
	void testSaveCustomer() {
		Customer customer = new Customer(1L, "Shaik", "Sania", "shaik@example.com", "9876543210", "Hyderabad",
				LocalDateTime.now());

		when(repo.save(customer)).thenReturn(customer);

		Customer saved = repo.save(customer);

		assertThat(saved).isNotNull();
		assertThat(saved.getEmail()).isEqualTo("shaik@example.com");
		
		verify(repo).save(customer);
	}

	@Test
	void testFindAllCustomers() {
		Customer c1 = new Customer(2L, "Sania", "Sultana", "sania@example.com", "9998887777", "Chennai",
				LocalDateTime.now());
		Customer c2 = new Customer(3L, "Test", "User", "test@example.com", "8887776666", "Bangalore",
				LocalDateTime.now());

		when(repo.findAll()).thenReturn(Arrays.asList(c1, c2));

		List<Customer> customers = repo.findAll();

		assertThat(customers).hasSize(2);
		verify(repo).findAll();
	}

	@Test
	void testFindById() {
		Customer customer = new Customer(4L, "First", "Last", "test@example.com", "7776665555", "Delhi",
				LocalDateTime.now());

		when(repo.findById(4L)).thenReturn(Optional.of(customer));

		Optional<Customer> found = repo.findById(4L);

		assertThat(found).isPresent();
		assertThat(found.get().getFirstName()).isEqualTo("First");
		verify(repo).findById(4L);
	}

	@Test
	void testFindByEmail() {
		Customer customer = new Customer(5L, "Email", "User", "emailuser@example.com", "6665554444", "Mumbai",
				LocalDateTime.now());

		when(repo.findByEmail("emailuser@example.com")).thenReturn(Optional.of(customer));

		Optional<Customer> found = repo.findByEmail("emailuser@example.com");

		assertThat(found).isPresent();
		assertThat(found.get().getLastName()).isEqualTo("User");
		verify(repo).findByEmail("emailuser@example.com");
	}

	@Test
	void testFindByPhone() {
		Customer customer = new Customer(6L, "Phone", "User", "phoneuser@example.com", "5554443333", "Pune",
				LocalDateTime.now());

		when(repo.findByPhone("5554443333")).thenReturn(Optional.of(customer));

		Optional<Customer> found = repo.findByPhone("5554443333");

		assertThat(found).isPresent();
		assertThat(found.get().getEmail()).isEqualTo("phoneuser@example.com");
		verify(repo).findByPhone("5554443333");
	}

	@Test
	void testExistsById() {
		when(repo.existsById(7L)).thenReturn(true);

		boolean exists = repo.existsById(7L);

		assertThat(exists).isTrue();
		verify(repo).existsById(7L);
	}

	@Test
	void testCountCustomers() {
		when(repo.count()).thenReturn(3L);

		long count = repo.count();

		assertThat(count).isEqualTo(3L);
		verify(repo).count();
	}

	@Test
	void testDeleteById() {
		repo.deleteById(8L);
		verify(repo).deleteById(8L);

		when(repo.findById(8L)).thenReturn(Optional.empty());
		Optional<Customer> found = repo.findById(8L);
		assertThat(found).isEmpty();
	}

	@Test
	void testDeleteAll() {
		repo.deleteAll();
		verify(repo).deleteAll();

		when(repo.findAll()).thenReturn(Collections.emptyList());
		List<Customer> customers = repo.findAll();
		assertThat(customers).isEmpty();
	}
}
