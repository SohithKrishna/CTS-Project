package com.project.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.project.db.CustomerRepository;
import com.project.exception.CustomerNotFoundException;
import com.project.model.Customer;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CustomerServiceTest {

	@Mock
	private CustomerRepository repo;

	@InjectMocks
	private CustomerService service;

	@Test
	void testCreateCustomer() {

		Customer customer = new Customer();
		customer.setFirstName("John");

		when(repo.save(any(Customer.class))).thenReturn(customer);

		Customer result = service.createCustomer(customer);

		assertNotNull(result);
		assertEquals("John", result.getFirstName());
		assertNotNull(customer.getCreatedAt());

		verify(repo, times(1)).save(customer);
	}

	@Test
	void testViewAllCustomers() {

		Customer c1 = new Customer();
		c1.setId(1L);

		Customer c2 = new Customer();
		c2.setId(2L);

		when(repo.findAll()).thenReturn(Arrays.asList(c1, c2));

		List<Customer> customers = service.viewAllCustomers();

		assertEquals(2, customers.size());
		verify(repo).findAll();
	}

	@Test
	void testDeleteCustomer() throws CustomerNotFoundException {

		Customer customer = new Customer();
		customer.setId(1L);

		when(repo.findById(1L)).thenReturn(Optional.of(customer));

		doNothing().when(repo).delete(customer);

		service.deleteCustomer(1L);

		verify(repo).delete(customer);
	}

	@Test
	void testDeleteCustomer_NotFound() {

		when(repo.findById(1L)).thenReturn(Optional.empty());

		assertThrows(CustomerNotFoundException.class, () -> service.deleteCustomer(1L));
	}

	@Test
	void testUpdateCustomer() throws CustomerNotFoundException {

		Customer existing = new Customer();
		existing.setId(1L);
		existing.setFirstName("Old");

		Customer updated = new Customer();
		updated.setFirstName("New");
		updated.setLastName("Smith");
		updated.setEmail("new@test.com");
		updated.setPhone("9876543210");
		updated.setAddress("Chennai");

		when(repo.findById(1L)).thenReturn(Optional.of(existing));

		when(repo.save(any(Customer.class))).thenAnswer(invocation -> invocation.getArgument(0));

		Customer result = service.updateCustomer(1L, updated);

		assertEquals("New", result.getFirstName());
		assertEquals("Smith", result.getLastName());

		verify(repo).save(existing);
	}

	@Test
	void testUpdateCustomer_NullCustomer() {

		IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
				() -> service.updateCustomer(1L, null));

		assertEquals("Customer details are missing", exception.getMessage());
	}

	@Test
	void testUpdateCustomer_NotFound() {

		Customer updated = new Customer();

		when(repo.findById(1L)).thenReturn(Optional.empty());

		assertThrows(CustomerNotFoundException.class, () -> service.updateCustomer(1L, updated));
	}

	@Test
	void testFindById() throws CustomerNotFoundException {

		Customer customer = new Customer();
		customer.setId(1L);

		when(repo.findById(1L)).thenReturn(Optional.of(customer));

		Customer result = service.findById(1L);

		assertEquals(1L, result.getId());
	}

	@Test
	void testFindById_NotFound() {
		when(repo.findById(1L)).thenReturn(Optional.empty());

		Customer customer = service.findById(1L);

		assertNull(customer);
	}

	@Test
	void testGetCustomerByEmail() throws CustomerNotFoundException {

		Customer customer = new Customer();
		customer.setEmail("john@test.com");

		when(repo.findByEmail("john@test.com")).thenReturn(Optional.of(customer));

		Customer result = service.getCustomerByEmail("john@test.com");

		assertEquals("john@test.com", result.getEmail());
	}

	@Test
	void testGetCustomerByEmail_NotFound() {

		when(repo.findByEmail("john@test.com")).thenReturn(Optional.empty());

		assertThrows(CustomerNotFoundException.class, () -> service.getCustomerByEmail("john@test.com"));
	}

	@Test
	void testGetCustomerByPhoneNumber() throws CustomerNotFoundException {

		Customer customer = new Customer();
		customer.setPhone("9876543210");

		when(repo.findByPhone("9876543210")).thenReturn(Optional.of(customer));

		Customer result = service.getCustomerByPhoneNumber("9876543210");

		assertEquals("9876543210", result.getPhone());
	}

	@Test
	void testGetCustomerByPhoneNumber_NotFound() {

		when(repo.findByPhone("9876543210")).thenReturn(Optional.empty());

		assertThrows(CustomerNotFoundException.class, () -> service.getCustomerByPhoneNumber("9876543210"));
	}
}