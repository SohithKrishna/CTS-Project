package com.project.ui;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.project.dto.CustomerRequestDTO;
import com.project.model.Customer;
import com.project.service.CustomerService;

@WebMvcTest(CustomerController.class)
class CustomerControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@MockitoBean
	private CustomerService service;

	@Test
	void testAddCustomer() throws Exception {

		Customer customer = new Customer();
		customer.setId(1L);
		customer.setFirstName("John");
		customer.setLastName("Smith");
		customer.setEmail("john@gmail.com");
		customer.setPhone("9876543210");
		customer.setAddress("Chennai");

		CustomerRequestDTO requestDTO = new CustomerRequestDTO();
		requestDTO.setCustomer(customer);

		when(service.createCustomer(any(Customer.class))).thenReturn(customer);

		mockMvc.perform(post("/customer/addCustomer").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(requestDTO))).andExpect(status().isCreated())
				.andExpect(jsonPath("$.message").value("Customer Saved Successfully"))
				.andExpect(jsonPath("$.httpStatusCode").value(200));
	}

	@Test
	void testViewAllCustomers() throws Exception {

		Customer customer = new Customer();
		customer.setId(1L);

		when(service.viewAllCustomers()).thenReturn(List.of(customer));

		mockMvc.perform(get("/customer/viewAllCustomers")).andExpect(status().isOk())
				.andExpect(jsonPath("$.customers.length()").value(1))
				.andExpect(jsonPath("$.httpStatusCode").value(200));
	}

	@Test
	void testViewCustomer() throws Exception {

		Customer customer = new Customer();
		customer.setId(1L);

		when(service.findById(1L)).thenReturn(customer);

		mockMvc.perform(get("/customer/viewCustomer/1")).andExpect(status().isOk())
				.andExpect(jsonPath("$.customer.id").value(1))
				.andExpect(jsonPath("$.message").value("Customer with id 1 Found"));
	}

	@Test
	void testUpdateCustomer() throws Exception {

		Customer customer = new Customer();
		customer.setId(1L);
		customer.setFirstName("Updated");
		customer.setLastName("User");
		customer.setEmail("updated.user@test.com");
		customer.setPhone("9876543210");
		customer.setAddress("Chennai");
		customer.setCreatedAt(LocalDateTime.now());

		CustomerRequestDTO requestDTO = new CustomerRequestDTO();
		requestDTO.setCustomer(customer);

		when(service.updateCustomer(eq(1L), any(Customer.class))).thenReturn(customer);

		mockMvc.perform(put("/customer/updateCustomer/{id}", 1L).contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(requestDTO))).andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.httpStatusCode").value(200))
				.andExpect(jsonPath("$.message").value("Customer with id 1 Updated Successfully"))
				.andExpect(jsonPath("$.customer.id").value(1))
				.andExpect(jsonPath("$.customer.firstName").value("Updated"));

		verify(service, times(1)).updateCustomer(eq(1L), any(Customer.class));
	}

	@Test
	void testDeleteCustomer() throws Exception {

		doNothing().when(service).deleteCustomer(1L);

		mockMvc.perform(delete("/customer/deleteCustomer/1")).andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("Customer with id 1 Deleted Successfully"));
	}

	@Test
	void testGetCustomerByEmail() throws Exception {

		Customer customer = new Customer();
		customer.setId(1L);
		customer.setEmail("john@gmail.com");

		when(service.getCustomerByEmail("john@gmail.com")).thenReturn(customer);

		mockMvc.perform(get("/customer/email/john@gmail.com")).andExpect(status().isOk())
				.andExpect(jsonPath("$.customer.email").value("john@gmail.com"))
				.andExpect(jsonPath("$.message").value("Customer fetched successfully"));
	}

	@Test
	void testGetCustomerByPhoneNumber() throws Exception {

		Customer customer = new Customer();
		customer.setId(1L);
		customer.setPhone("9876543210");

		when(service.getCustomerByPhoneNumber("9876543210")).thenReturn(customer);

		mockMvc.perform(get("/customer/phone/9876543210")).andExpect(status().isOk())
				.andExpect(jsonPath("$.customer.phone").value("9876543210"))
				.andExpect(jsonPath("$.message").value("Customer fetched successfully"));
	}

	@Test
	void testAddCustomer_NullCustomer() throws Exception {

		CustomerRequestDTO requestDTO = new CustomerRequestDTO();

		mockMvc.perform(post("/customer/addCustomer").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(requestDTO))).andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.message").value("Invalid request: customer is missing"));
	}

	@Test
	void testUpdateCustomer_NullCustomer() throws Exception {

		CustomerRequestDTO requestDTO = new CustomerRequestDTO();

		mockMvc.perform(put("/customer/updateCustomer/1").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(requestDTO))).andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.message").value("Customer details are missing"));
	}

	@Test
	void testViewAllCustomers_NoContent() throws Exception {

		when(service.viewAllCustomers()).thenReturn(List.of());

		mockMvc.perform(get("/customer/viewAllCustomers")).andExpect(status().isNoContent());
	}
}