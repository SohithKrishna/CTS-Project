package com.project.security;
 
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
 
@Configuration
@EnableWebSecurity
public class MyConfig {
 
    @Bean
    public InMemoryUserDetailsManager userDetailsService() {
        System.out.println("******** BANKING SECURITY LOADED ********");
 
        UserDetails customerUser = User.withUsername("bankCustomer")
                .password("{noop}cust123")
                .roles("USER")
                .build();
 
        UserDetails bankManager = User.withUsername("bankManager")
                .password("{noop}manager123")
                .roles("MANAGER")
                .build();
 
        UserDetails bankAdmin = User.withUsername("bankAdmin")
                .password("{noop}admin123")
                .roles("ADMIN")
                .build();
 
        return new InMemoryUserDetailsManager(customerUser, bankManager, bankAdmin);
    }
 
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
 
                // CUSTOMER APIs
                .requestMatchers(HttpMethod.GET, "/customer/viewAllCustomers").hasAnyRole("MANAGER","ADMIN")
                .requestMatchers(HttpMethod.GET, "/customer/viewCustomer/*").hasAnyRole("USER","MANAGER","ADMIN")
                .requestMatchers(HttpMethod.GET, "/customer/email/*").hasAnyRole("USER","MANAGER","ADMIN")
                .requestMatchers(HttpMethod.GET, "/customer/phone/*").hasAnyRole("USER","MANAGER","ADMIN")
                .requestMatchers(HttpMethod.POST, "/customer/addCustomer").hasAnyRole("MANAGER","ADMIN")
                .requestMatchers(HttpMethod.PUT, "/customer/updateCustomer/*").hasAnyRole("MANAGER","ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/customer/deleteCustomer/*").hasRole("ADMIN")
 
                // ACCOUNT APIs
                .requestMatchers(HttpMethod.GET, "/account/viewAllAccounts").hasAnyRole("MANAGER","ADMIN")
                .requestMatchers(HttpMethod.GET, "/account/viewAccount/*").hasAnyRole("USER","MANAGER","ADMIN")
                .requestMatchers(HttpMethod.GET, "/account/customer/*").hasAnyRole("USER","MANAGER","ADMIN")
                .requestMatchers(HttpMethod.GET, "/account/number/*").hasAnyRole("USER","MANAGER","ADMIN")
                .requestMatchers(HttpMethod.GET, "/account/type/*").hasAnyRole("MANAGER","ADMIN")
                .requestMatchers(HttpMethod.POST, "/account/addAccount").hasAnyRole("MANAGER","ADMIN")
                .requestMatchers(HttpMethod.PUT, "/account/updateAccount/*").hasAnyRole("MANAGER","ADMIN")
                .requestMatchers(HttpMethod.PUT, "/account/updateBalance/*/*").hasAnyRole("MANAGER","ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/account/deleteAccount/*").hasRole("ADMIN")
 
                // TRANSACTION APIs
                .requestMatchers(HttpMethod.GET, "/transaction/viewAllTransactions").hasAnyRole("MANAGER","ADMIN")
                .requestMatchers(HttpMethod.GET, "/transaction/viewTransaction/*").hasAnyRole("USER","MANAGER","ADMIN")
                .requestMatchers(HttpMethod.GET, "/transaction/account/*").hasAnyRole("USER","MANAGER","ADMIN")
                .requestMatchers(HttpMethod.GET, "/transaction/type/*").hasAnyRole("MANAGER","ADMIN")
                .requestMatchers(HttpMethod.GET, "/transaction/status/*").hasAnyRole("MANAGER","ADMIN")
                .requestMatchers(HttpMethod.POST, "/transaction/addTransaction").hasAnyRole("USER","MANAGER","ADMIN")
                .requestMatchers(HttpMethod.PUT, "/transaction/updateTransaction/*").hasAnyRole("MANAGER","ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/transaction/deleteTransaction/*").hasRole("ADMIN")
 
                .anyRequest().authenticated()
            )
            .httpBasic(Customizer.withDefaults());
 
        return http.build();
    }
}