package com.project.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.db.AccountRepository;
import com.project.dto.AccountRequestDTO;
import com.project.dto.AccountResponseDTO;
import com.project.exception.AccountNotFoundException;
import com.project.exception.InsufficientBalanceException;
import com.project.exception.InvalidTransactionTypeException;
import com.project.model.Account;

@Service
public class AccountService {

	@Autowired
	AccountRepository repo;

	public Account createAccount(Account account) {
		if (repo.existsByAccountNumber(account.getAccountNumber())) {
			throw new RuntimeException("Account Number Already Exists");
		}
		account.setCreatedAt(LocalDateTime.now());
		return repo.save(account);
	}

	public List<Account> viewAllAccounts() {
		return repo.findAll();
	}

	public void deleteAccount(Long id) throws AccountNotFoundException {
		Account account = repo.findById(id)
				.orElseThrow(() -> new AccountNotFoundException("Account with id " + id + " Not Found"));
		repo.delete(account);
	}

	public Account updateAccount(Long id, AccountRequestDTO accountDTO) throws AccountNotFoundException {
		Account existingAccount = repo.findById(id)
				.orElseThrow(() -> new AccountNotFoundException("Account with id " + id + " Not Found"));
		Account updatedDetails = accountDTO.getAccount();
		existingAccount.setAccountNumber(updatedDetails.getAccountNumber());
		existingAccount.setCustomerId(updatedDetails.getCustomerId());
		existingAccount.setType(updatedDetails.getType());
		existingAccount.setBalance(updatedDetails.getBalance());
		return repo.save(existingAccount);
	}

	public Account findById(Long id) throws AccountNotFoundException {
		return repo.findById(id)
				.orElseThrow(() -> new AccountNotFoundException("Account with id " + id + " not found"));
	}

	public Account updateBalance(Long id, String type, BigDecimal amount) throws AccountNotFoundException {
		Account account = repo.findById(id).orElseThrow(() -> new AccountNotFoundException("Account Not Found"));
		if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
			throw new IllegalArgumentException("Amount must be greater than zero");
		}
		if (type.equalsIgnoreCase("DEPOSIT")) {
			account.setBalance(account.getBalance().add(amount));
		} else if (type.equalsIgnoreCase("WITHDRAW")) {
			if (account.getBalance().compareTo(amount) < 0) {
				throw new InsufficientBalanceException("Insufficient Balance");
			}
			account.setBalance(account.getBalance().subtract(amount));
		} else {
			// throw new IllegalArgumentException("Invalid Transaction Type");
			throw new InvalidTransactionTypeException("Invalid Transaction Type");
		}
		return repo.save(account);
	}

	private AccountResponseDTO mapToResponseDto(Account account) {
		AccountResponseDTO dto = new AccountResponseDTO();
		dto.setAccount(account);
		dto.setHttpStatusCode(200);
		dto.setMessage("Account by Customer fetched");
		return dto;
	}

	public List<Account> getAccountsByCustomerId(Long customerId) throws AccountNotFoundException {
		List<Account> accounts = repo.findByCustomerId(customerId);
		if (accounts.isEmpty()) {
			throw new AccountNotFoundException("No accounts found for customer id " + customerId);
		}
		return accounts;
	}

	public AccountResponseDTO getAccountByAccountNumber(String accountNumber) throws AccountNotFoundException {
		Account account = repo.findByAccountNumber(accountNumber).orElseThrow(
				() -> new AccountNotFoundException("Account Not Found with account number: " + accountNumber));
		return mapToResponseDto(account);
	}

	public List<Account> getAccountsByType(String type) throws AccountNotFoundException {
		List<Account> accounts = repo.findByType(type);
		if (accounts.isEmpty()) {
			throw new AccountNotFoundException("No accounts found with type: " + type);
		}
		return accounts;
	}

}
