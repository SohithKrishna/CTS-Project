package com.project.db;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.model.Account;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {

	List<Account> findByCustomerId(Long customerId);

	Optional<Account> findByAccountNumber(String accountNumber);

	List<Account> findByType(String type);
	
	boolean existsByAccountNumber(String accountNumber);
}
