package com.project.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.project.feign.dto.CustomerDTO;

@FeignClient(name = "CUSTOMER-SERVICE")
public interface CustomerFeignClient {
	
	@GetMapping("/customer/viewCustomer/{id}")
	CustomerDTO getCustomerById(@PathVariable("id") Long id);
}
