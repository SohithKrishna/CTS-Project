package com.project.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "accounts")
public class Account {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank(message = "Account Number is mandatory and maximum of 15 characters")
	@Size(max = 15, message = "Size must be between 1 - 15 characters")
	@Column(unique = true, nullable = false)
	private String accountNumber;
	
	@NotNull(message = "Customer ID field is mandatory")
	@Column(nullable = false)
	private Long customerId;
	
	@NotBlank(message = "Account type should be mentioned")
	@Size(max = 20)
	private String type;
	
	@NotNull(message = "Balance field is required")
	@DecimalMin(value = "0.00", inclusive = true)
	@Digits(integer = 13, fraction = 2)
	private BigDecimal balance;
	
	@Column(nullable = false)
	private LocalDateTime createdAt;

	public Account(Long id, String accountNumber, Long customerId, String type, BigDecimal balance, LocalDateTime createdAt) {
		super();
		this.id = id;
		this.accountNumber = accountNumber;
		this.customerId = customerId;
		this.type = type;
		this.balance = balance;
		this.createdAt = createdAt;
	}

	public Account() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	@Override
	public String toString() {
		return "Account [id=" + id + ", accountNumber=" + accountNumber + ", customerId=" + customerId + ", type="
				+ type + ", balance=" + balance + ", createdAt=" + createdAt + "]";
	}
	
}
