package com.project.advice;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.project.dto.ErrorResponse;
import com.project.exception.AccountNotFoundException;
import com.project.exception.CustomerNotFoundException;
import com.project.exception.InsufficientBalanceException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(AccountNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleAccountNotFound(AccountNotFoundException ex) {
	    ErrorResponse response =
	            new ErrorResponse(HttpStatus.NOT_FOUND.value(), ex.getMessage());

	    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	}

	@ExceptionHandler(CustomerNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleCustomerNotFound(CustomerNotFoundException ex) {
		ErrorResponse response = new ErrorResponse(404, ex.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(error -> {
			String field = error.getField();
			if (field.contains(".")) {
				field = field.substring(field.lastIndexOf(".") + 1);
			}
			errors.put(field, error.getDefaultMessage());
		});
		return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<Map<String, String>> handleConstraintViolation(ConstraintViolationException ex) {
		Map<String, String> errors = new HashMap<>();
		ex.getConstraintViolations().forEach(violation -> {
			errors.put(violation.getPropertyPath().toString(), violation.getMessage());
		});
		return ResponseEntity.badRequest().body(errors);
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<Map<String, Object>> handleJsonParseError(HttpMessageNotReadableException ex,
			HttpServletRequest request) {
		Map<String, Object> errorResponse = new LinkedHashMap<>();
		errorResponse.put("status", HttpStatus.BAD_REQUEST.value());
		errorResponse.put("message", "Please fill all the fields");
		return ResponseEntity.badRequest().body(errorResponse);
	}
	
//	@ExceptionHandler(exception = AccountNotFoundException.class)
//	public ErrorResponse handleException1(Exception e) {
//		ErrorResponse response = new ErrorResponse(404, e.getMessage());
//		return response;
//	}
	

//	@ExceptionHandler(InsufficientBalanceException.class)
//	public ResponseEntity<Map<String, Object>> handleInsufficientBalance(InsufficientBalanceException ex) {
//		Map<String, Object> response = new HashMap<>();
//		response.put("status", 400);
//		response.put("message", ex.getMessage());
//		return ResponseEntity.badRequest().body(response);
//	}
//	@ExceptionHandler(InsufficientBalanceException.class)
//	public ResponseEntity<ErrorResponse> handleInsufficientBalance(InsufficientBalanceException ex) {
//		ErrorResponse response = new ErrorResponse(HttpStatus.BAD_REQUEST.value(), ex.getMessage());
//		return ResponseEntity.badRequest().body(response);
//	}

}
