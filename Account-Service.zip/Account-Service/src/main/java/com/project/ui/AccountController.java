package com.project.ui;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.dto.AccountListResponseDTO;
import com.project.dto.AccountRequestDTO;
import com.project.dto.AccountResponseDTO;
import com.project.exception.AccountNotFoundException;
import com.project.feign.CustomerFeignClient;
import com.project.feign.dto.CustomerDTO;
import com.project.model.Account;
import com.project.service.AccountService;

import feign.FeignException;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/account")
@Tag(name = "Account Controller", description = "This is Account Controller")
public class AccountController {

	@Autowired
	AccountService service;

	@Autowired
	CustomerFeignClient customerFeignClient;

	@PostMapping("/addAccount")
	@Operation(summary = "Add Account")
	public ResponseEntity<AccountResponseDTO> f1(@Valid @RequestBody AccountRequestDTO accountdto) {
		Account account = accountdto.getAccount();
		if (account == null) {
			return ResponseEntity.badRequest()
					.body(new AccountResponseDTO(null, 400, "Invalid request: account is missing"));
		}
		CustomerDTO customerDTO;
		try {
			customerDTO = customerFeignClient.getCustomerById(account.getCustomerId());
		} catch (FeignException.NotFound e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
					new AccountResponseDTO(null, 404, "Customer with id " + account.getCustomerId() + " Not Found"));
		}
		try {
			Account created = service.createAccount(account);
			return ResponseEntity.status(HttpStatus.CREATED)
					.body(new AccountResponseDTO(created, 200, "Account Saved Successfully"));
		} catch (RuntimeException e) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body(new AccountResponseDTO(null, 409, e.getMessage()));
		}
	}

	@PutMapping("/updateBalance/{id}/{type}")
	@Hidden
	public ResponseEntity<Account> updateBalance(@PathVariable Long id, @PathVariable String type,
			@RequestBody BigDecimal amount) throws AccountNotFoundException {
		return ResponseEntity.ok(service.updateBalance(id, type, amount));
	}

	@GetMapping("/viewAllAccounts")
	@Operation(summary = "View All Accounts")
	public ResponseEntity<AccountListResponseDTO> f2() {
		List<Account> accounts = service.viewAllAccounts();
		AccountListResponseDTO dto = new AccountListResponseDTO();
		dto.setHttpStatusCode(HttpStatus.OK.value());
		if (accounts.isEmpty()) {
			dto.setMessage("No Accounts found");
		} else {
			dto.setMessage(accounts.size() + " Account objects fetched");
		}
		dto.setAccounts(accounts);
		return ResponseEntity.ok(dto);
	}

	@GetMapping("/viewAccount/{id}")
	@Operation(summary = "View Account by ID")
	public ResponseEntity<AccountResponseDTO> f3(@PathVariable Long id) throws AccountNotFoundException {

		Account account = service.findById(id);

		AccountResponseDTO dto = new AccountResponseDTO();
		dto.setHttpStatusCode(HttpStatus.OK.value());
		dto.setAccount(account);
		dto.setMessage("Account found");

		return ResponseEntity.ok(dto);
	}

	@PutMapping("/updateAccount/{id}")
	@Operation(summary = "Update Account")
	public ResponseEntity<AccountResponseDTO> updateAccount(@PathVariable Long id, @Valid @RequestBody AccountRequestDTO accountDTO) throws AccountNotFoundException {
		Account account = accountDTO.getAccount();
		if (account == null) {
			return ResponseEntity.badRequest().body(new AccountResponseDTO(null, 400, "Account details are missing"));
		}
		try {
			customerFeignClient.getCustomerById(account.getCustomerId());
			Account updatedAccount = service.updateAccount(id, accountDTO);
			return ResponseEntity.ok(new AccountResponseDTO(updatedAccount, 200, "Account updated successfully"));
		} catch (FeignException.NotFound ex) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
					new AccountResponseDTO(null, 404, "Customer with id " + account.getCustomerId() + " not found"));
		}
	}

	@DeleteMapping("/deleteAccount/{id}")
	@Operation(summary = "Delete Account")
	public ResponseEntity<AccountResponseDTO> deleteAccount(@PathVariable Long id) throws AccountNotFoundException {
		service.deleteAccount(id);

		AccountResponseDTO dto = new AccountResponseDTO();
		dto.setHttpStatusCode(HttpStatus.OK.value());
		dto.setMessage("Account with id " + id + " Deleted Successfully");
		dto.setAccount(null);

		return ResponseEntity.ok(dto);
	}

	@GetMapping("/customer/{customerId}")
	@Operation(summary = "Get Accounts by Customer ID")
	public ResponseEntity<AccountListResponseDTO> getAccountsByCustomerId(@PathVariable Long customerId)
			throws AccountNotFoundException {
		List<Account> accounts = service.getAccountsByCustomerId(customerId);

		AccountListResponseDTO responseDTO = new AccountListResponseDTO();
		responseDTO.setAccounts(accounts);
		responseDTO.setHttpStatusCode(200);
		responseDTO.setMessage(accounts.size() + " accounts fetched successfully");

		return ResponseEntity.ok(responseDTO);
	}

	@GetMapping("/number/{accountNumber}")
	@Operation(summary = "Get Account by Account Number")
	public ResponseEntity<AccountResponseDTO> getAccountByAccountNumber(@PathVariable String accountNumber)
			throws AccountNotFoundException {
		return ResponseEntity.ok(service.getAccountByAccountNumber(accountNumber));
	}

	@GetMapping("/type/{type}")
	@Operation(summary = "Get Account by Account Type")
	public ResponseEntity<AccountListResponseDTO> getAccountsByType(@PathVariable String type)
			throws AccountNotFoundException {
		List<Account> accounts = service.getAccountsByType(type);

		AccountListResponseDTO responseDTO = new AccountListResponseDTO();
		responseDTO.setAccounts(accounts);
		responseDTO.setHttpStatusCode(200);
		responseDTO.setMessage(accounts.size() + " accounts fetched successfully");

		return ResponseEntity.ok(responseDTO);
	}
}
