package com.project.dto;

import com.project.model.Account;

import jakarta.validation.Valid;

public class AccountRequestDTO {

	@Valid
	Account account;

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}
	
}
