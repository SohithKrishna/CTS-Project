package com.project.dto;

import com.project.model.Account;

public class AccountResponseDTO {
	
	Account account;
	int httpStatusCode;
	String message;
	
	public AccountResponseDTO(Account account, int httpStatusCode, String message) {
		super();
		this.account = account;
		this.httpStatusCode = httpStatusCode;
		this.message = message;
	}
	
	public AccountResponseDTO() {
		super();
	}

	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public int getHttpStatusCode() {
		return httpStatusCode;
	}
	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
