package com.project.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.project.db.AccountRepository;
import com.project.dto.AccountRequestDTO;
import com.project.dto.AccountResponseDTO;
import com.project.exception.AccountNotFoundException;
import com.project.exception.InsufficientBalanceException;
import com.project.exception.InvalidTransactionTypeException;
import com.project.model.Account;

@ExtendWith(MockitoExtension.class)
class AccountServiceTest {

	@Mock
	private AccountRepository repo;

	@InjectMocks
	private AccountService service;

	@Test
	void testCreateAccount() {
		Account account = new Account();
		account.setAccountNumber("ACC1001");
		account.setCustomerId(1L);
		account.setType("SAVINGS");
		account.setBalance(new BigDecimal("5000"));
		when(repo.save(any(Account.class))).thenReturn(account);
		Account result = service.createAccount(account);
		assertNotNull(result);
		assertEquals("ACC1001", result.getAccountNumber());
		assertEquals("SAVINGS", result.getType());
		assertEquals(new BigDecimal("5000"), account.getBalance());
		verify(repo, times(1)).save(any(Account.class));
	}

	@Test
	void testViewAllAccounts() {
		Account a1 = new Account();
		Account a2 = new Account();
		when(repo.findAll()).thenReturn(Arrays.asList(a1, a2));
		List<Account> accounts = service.viewAllAccounts();
		assertEquals(2, accounts.size());
		verify(repo).findAll();
	}

	@Test
	void testDeleteAccountNotFound() {
		when(repo.findById(1L)).thenReturn(Optional.empty());
		assertThrows(AccountNotFoundException.class, () -> service.deleteAccount(1L));
	}

	@Test
	void testFindById() throws AccountNotFoundException {
		Account account = new Account();
		account.setId(1L);
		when(repo.findById(1L)).thenReturn(Optional.of(account));
		Account result = service.findById(1L);
		assertNotNull(result);
		assertEquals(1L, result.getId());
		verify(repo).findById(1L);
	}

	@Test
	void testFindByIdNotFound() {
		when(repo.findById(100L)).thenReturn(Optional.empty());
		assertThrows(AccountNotFoundException.class, () -> service.findById(100L));
		verify(repo).findById(100L);
	}

	@Test
	void testDeleteAccount() throws AccountNotFoundException {
		Account account = new Account();
		account.setId(1L);
		when(repo.findById(1L)).thenReturn(Optional.of(account));
		service.deleteAccount(1L);
		verify(repo).delete(account);
	}

	@Test
	void testUpdateAccount() throws AccountNotFoundException {
		Account existing = new Account();
		existing.setId(1L);
		Account updated = new Account();
		updated.setAccountNumber("ACC999");
		updated.setCustomerId(2L);
		updated.setType("CURRENT");
		updated.setBalance(new BigDecimal("9000"));
		AccountRequestDTO dto = new AccountRequestDTO();
		dto.setAccount(updated);
		when(repo.findById(1L)).thenReturn(Optional.of(existing));
		when(repo.save(any(Account.class))).thenReturn(existing);
		Account result = service.updateAccount(1L, dto);
		assertNotNull(result);
		assertEquals("ACC999", result.getAccountNumber());
		assertEquals(Long.valueOf(2L), result.getCustomerId());
		assertEquals("CURRENT", result.getType());
		assertEquals(new BigDecimal("9000"), result.getBalance());
		verify(repo).findById(1L);
		verify(repo).save(existing);
	}

	@Test
	void testUpdateAccountNotFound() {
		AccountRequestDTO dto = new AccountRequestDTO();
		when(repo.findById(1L)).thenReturn(Optional.empty());
		assertThrows(AccountNotFoundException.class, () -> service.updateAccount(1L, dto));
		verify(repo).findById(1L);
	}

	@Test
	void testDeposit() throws AccountNotFoundException {
		Account account = new Account();
		account.setId(1L);
		account.setBalance(new BigDecimal("1000"));
		when(repo.findById(1L)).thenReturn(Optional.of(account));
		when(repo.save(any(Account.class))).thenReturn(account);
		Account result = service.updateBalance(1L, "DEPOSIT", new BigDecimal("500"));
		assertNotNull(result);
		assertEquals(new BigDecimal("1500"), result.getBalance());
		verify(repo).save(account);
	}

	@Test
	void testWithdraw() throws AccountNotFoundException {
		Account account = new Account();
		account.setId(1L);
		account.setBalance(new BigDecimal("5000"));
		when(repo.findById(1L)).thenReturn(Optional.of(account));
		when(repo.save(any(Account.class))).thenReturn(account);
		Account result = service.updateBalance(1L, "WITHDRAW", new BigDecimal("2000"));
		assertNotNull(result);
		assertEquals(new BigDecimal("3000"), result.getBalance());
		verify(repo).save(account);
	}

	@Test
	void testInsufficientBalance() {
		Account account = new Account();
		account.setId(1L);
		account.setBalance(new BigDecimal("1000"));
		when(repo.findById(1L)).thenReturn(Optional.of(account));
		assertThrows(InsufficientBalanceException.class, () -> {
			service.updateBalance(1L, "WITHDRAW", new BigDecimal("5000"));
		});
		verify(repo, times(0)).save(any(Account.class));
	}

	@Test
	void testInvalidTransactionType() throws AccountNotFoundException {
		Account account = new Account();
		account.setId(1L);
		account.setBalance(new BigDecimal("1000"));
		when(repo.findById(1L)).thenReturn(Optional.of(account));
		InvalidTransactionTypeException ex = assertThrows(InvalidTransactionTypeException.class,
				() -> service.updateBalance(1L, "TRANSFER", new BigDecimal("500")));
		assertEquals("Invalid Transaction Type", ex.getMessage());
		verify(repo).findById(1L);
		verify(repo, never()).save(any(Account.class));
	}

	@Test
	void testGetAccountsByCustomerId() throws AccountNotFoundException {
		Account account = new Account();
		account.setCustomerId(1L);
		when(repo.findByCustomerId(1L)).thenReturn(List.of(account));
		List<Account> accounts = service.getAccountsByCustomerId(1L);
		assertNotNull(accounts);
		assertEquals(1, accounts.size());
		verify(repo).findByCustomerId(1L);
	}

	@Test
	void testGetAccountsByCustomerIdNotFound() {
		when(repo.findByCustomerId(1L)).thenReturn(Collections.emptyList());
		assertThrows(AccountNotFoundException.class, () -> service.getAccountsByCustomerId(1L));
	}

	@Test
	void testGetAccountByAccountNumber() throws AccountNotFoundException {
		Account account = new Account();
		account.setAccountNumber("ACC1001");
		when(repo.findByAccountNumber("ACC1001")).thenReturn(Optional.of(account));
		AccountResponseDTO response = service.getAccountByAccountNumber("ACC1001");
		assertNotNull(response);
		assertEquals(200, response.getHttpStatusCode());
		assertEquals(account, response.getAccount());
		verify(repo).findByAccountNumber("ACC1001");
	}

	@Test
	void testGetAccountByAccountNumberNotFound() {
		when(repo.findByAccountNumber("ACC9999")).thenReturn(Optional.empty());
		assertThrows(AccountNotFoundException.class, () -> service.getAccountByAccountNumber("ACC9999"));
	}

	@Test
	void testGetAccountsByType() throws AccountNotFoundException {
		Account account = new Account();
		account.setType("SAVINGS");
		when(repo.findByType("SAVINGS")).thenReturn(List.of(account));
		List<Account> accounts = service.getAccountsByType("SAVINGS");
		assertNotNull(accounts);
		assertEquals(1, accounts.size());
		verify(repo).findByType("SAVINGS");
	}

	@Test
	void testGetAccountsByTypeNotFound() {
		when(repo.findByType("CURRENT")).thenReturn(Collections.emptyList());
		assertThrows(AccountNotFoundException.class, () -> service.getAccountsByType("CURRENT"));
	}
}