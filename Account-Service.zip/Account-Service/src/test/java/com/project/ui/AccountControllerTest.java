package com.project.ui;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.project.dto.AccountListResponseDTO;
import com.project.dto.AccountRequestDTO;
import com.project.dto.AccountResponseDTO;
import com.project.feign.CustomerFeignClient;
import com.project.feign.dto.CustomerDTO;
import com.project.model.Account;
import com.project.service.AccountService;

@WebMvcTest(AccountController.class)
class AccountControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@MockitoBean
	private AccountService service;

	@MockitoBean
	private CustomerFeignClient customerFeignClient;

	@Test
	void testAddAccount_Success() throws Exception {

		Account account = new Account();
		account.setId(1L);
		account.setAccountNumber("ACC001");
		account.setCustomerId(101L);
		account.setType("SAVINGS");
		account.setBalance(new BigDecimal("1000.00"));

		AccountRequestDTO requestDTO = new AccountRequestDTO();
		requestDTO.setAccount(account);

		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setId(101L);

		when(customerFeignClient.getCustomerById(101L)).thenReturn(customerDTO);

		when(service.createAccount(any(Account.class))).thenReturn(account);

		mockMvc.perform(post("/account/addAccount").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(requestDTO))).andExpect(status().isCreated())
				.andExpect(jsonPath("$.httpStatusCode").value(200))
				.andExpect(jsonPath("$.message").value("Account Saved Successfully"));
	}

	@Test
	void testViewAllAccounts() throws Exception {

		Account account1 = new Account();
		account1.setId(1L);

		Account account2 = new Account();
		account2.setId(2L);

		List<Account> accounts = Arrays.asList(account1, account2);

		when(service.viewAllAccounts()).thenReturn(accounts);

		mockMvc.perform(get("/account/viewAllAccounts")).andExpect(status().isOk())
				.andExpect(jsonPath("$.httpStatusCode").value(200)).andExpect(jsonPath("$.accounts.length()").value(2));
	}

	@Test
	void testViewAccountById() throws Exception {

		Account account = new Account();
		account.setId(1L);

		when(service.findById(1L)).thenReturn(account);

		mockMvc.perform(get("/account/viewAccount/1")).andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("Account found")).andExpect(jsonPath("$.account.id").value(1));
	}

	@Test
	void testUpdateAccount() throws Exception {

		Account account = new Account();
		account.setId(1L);
		account.setAccountNumber("ACC001");
		account.setCustomerId(101L);
		account.setType("SAVINGS");
		account.setBalance(new BigDecimal("1000.00"));

		AccountRequestDTO requestDTO = new AccountRequestDTO();
		requestDTO.setAccount(account);

		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setId(101L);

		when(customerFeignClient.getCustomerById(101L)).thenReturn(customerDTO);

		when(service.updateAccount(anyLong(), any(AccountRequestDTO.class))).thenReturn(account);

		mockMvc.perform(put("/account/updateAccount/1").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(requestDTO))).andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("Account updated successfully"));
	}

	@Test
	void testDeleteAccount() throws Exception {

		doNothing().when(service).deleteAccount(1L);

		mockMvc.perform(delete("/account/deleteAccount/1")).andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("Account with id 1 Deleted Successfully"));
	}

	@Test
	void testGetAccountsByCustomerId() throws Exception {

		Account account = new Account();
		account.setId(1L);
		account.setCustomerId(101L);

		when(service.getAccountsByCustomerId(101L)).thenReturn(List.of(account));

		mockMvc.perform(get("/account/customer/101")).andExpect(status().isOk())
				.andExpect(jsonPath("$.accounts.length()").value(1)).andExpect(jsonPath("$.httpStatusCode").value(200));
	}

	@Test
	void testGetAccountByAccountNumber() throws Exception {

		Account account = new Account();
		account.setId(1L);
		account.setAccountNumber("ACC001");

		AccountResponseDTO responseDTO = new AccountResponseDTO(account, 200, "Account Found");

		when(service.getAccountByAccountNumber("ACC001")).thenReturn(responseDTO);

		mockMvc.perform(get("/account/number/ACC001")).andExpect(status().isOk())
				.andExpect(jsonPath("$.account.accountNumber").value("ACC001"));
	}

	@Test
	void testGetAccountsByType() throws Exception {

		Account account = new Account();
		account.setId(1L);
		account.setType("SAVINGS");

		when(service.getAccountsByType("SAVINGS")).thenReturn(List.of(account));

		mockMvc.perform(get("/account/type/SAVINGS")).andExpect(status().isOk())
				.andExpect(jsonPath("$.accounts.length()").value(1)).andExpect(jsonPath("$.httpStatusCode").value(200))
				.andExpect(jsonPath("$.message").value("1 accounts fetched successfully"));
	}

	@Test
	void testUpdateBalance() throws Exception {

		Account account = new Account();
		account.setId(1L);
		account.setBalance(new BigDecimal("5000"));

		when(service.updateBalance(1L, "deposit", new BigDecimal("1000"))).thenReturn(account);

		mockMvc.perform(put("/account/updateBalance/1/deposit").contentType(MediaType.APPLICATION_JSON).content("1000"))
				.andExpect(status().isOk());
	}
}