package com.project.db;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.project.model.Account;

@DataJpaTest
public class AccountRepoTest {

	@Mock
	private AccountRepository repo;

	@Test
	void testSaveAccount() {
		Account account = new Account(null, "ACC1001", 1L, "SAVINGS", new BigDecimal("5000"), LocalDateTime.now());

		when(repo.save(account)).thenReturn(account);

		Account saved = repo.save(account);

		assertThat(saved).isNotNull();
		assertThat(saved.getAccountNumber()).isEqualTo("ACC1001");
		verify(repo).save(account);
	}

	@Test
	void testFindAllAccounts() {
		Account a1 = new Account(null, "ACC2001", 2L, "CURRENT", new BigDecimal("8000"), LocalDateTime.now());
		Account a2 = new Account(null, "ACC2002", 3L, "SAVINGS", new BigDecimal("6000"), LocalDateTime.now());

		when(repo.findAll()).thenReturn(Arrays.asList(a1, a2));

		List<Account> accounts = repo.findAll();

		assertThat(accounts).hasSize(2);
		verify(repo).findAll();
	}

	@Test
	void testFindById() {
		Account account = new Account(1L, "ACC3001", 4L, "CURRENT", new BigDecimal("9000"), LocalDateTime.now());

		when(repo.findById(1L)).thenReturn(Optional.of(account));

		Optional<Account> found = repo.findById(1L);

		assertThat(found).isPresent();
		assertThat(found.get().getType()).isEqualTo("CURRENT");
		verify(repo).findById(1L);
	}

	@Test
	void testFindByAccountNumber() {
		Account account = new Account(null, "ACC4001", 5L, "SAVINGS", new BigDecimal("10000"), LocalDateTime.now());

		when(repo.findByAccountNumber("ACC4001")).thenReturn(Optional.of(account));

		Optional<Account> found = repo.findByAccountNumber("ACC4001");

		assertThat(found).isPresent();
		assertThat(found.get().getCustomerId()).isEqualTo(5L);
		verify(repo).findByAccountNumber("ACC4001");
	}

	@Test
	void testFindByCustomerId() {
		Account account = new Account(null, "ACC5001", 6L, "CURRENT", new BigDecimal("2000"), LocalDateTime.now());

		when(repo.findByCustomerId(6L)).thenReturn(List.of(account));

		List<Account> accounts = repo.findByCustomerId(6L);

		assertThat(accounts).isNotEmpty();
		assertThat(accounts.get(0).getAccountNumber()).isEqualTo("ACC5001");
		verify(repo).findByCustomerId(6L);
	}

	@Test
	void testFindByType() {
		Account account = new Account(null, "ACC6001", 7L, "SAVINGS", new BigDecimal("7000"), LocalDateTime.now());

		when(repo.findByType("SAVINGS")).thenReturn(List.of(account));

		List<Account> accounts = repo.findByType("SAVINGS");

		assertThat(accounts).isNotEmpty();
		assertThat(accounts.get(0).getBalance()).isEqualTo(new BigDecimal("7000"));
		verify(repo).findByType("SAVINGS");
	}

	@Test
	void testExistsById() {
		when(repo.existsById(8L)).thenReturn(true);

		boolean exists = repo.existsById(8L);

		assertThat(exists).isTrue();
		verify(repo).existsById(8L);
	}

	@Test
	void testCountAccounts() {
		when(repo.count()).thenReturn(5L);

		long count = repo.count();

		assertThat(count).isEqualTo(5L);
		verify(repo).count();
	}

	@Test
	void testDeleteById() {
		repo.deleteById(11L);
		verify(repo).deleteById(11L);

		when(repo.findById(11L)).thenReturn(Optional.empty());
		Optional<Account> found = repo.findById(11L);
		assertThat(found).isEmpty();
	}

	@Test
	void testDeleteAll() {
		repo.deleteAll();
		verify(repo).deleteAll();

		when(repo.findAll()).thenReturn(Collections.emptyList());
		List<Account> accounts = repo.findAll();
		assertThat(accounts).isEmpty();
	}
}
