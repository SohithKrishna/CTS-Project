package com.project.db;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.project.model.Transaction;

@DataJpaTest
public class TransactionRepoTest {

	@Mock
	private TransactionRepository repo;

	@Test
	void testSaveTransaction() {
		Transaction tx = new Transaction(1L, 100L, "DEPOSIT", new BigDecimal("5000"), LocalDateTime.now(), "SUCCESS");

		when(repo.save(tx)).thenReturn(tx);

		Transaction saved = repo.save(tx);

		assertThat(saved).isNotNull();
		assertThat(saved.getType()).isEqualTo("DEPOSIT");
		verify(repo).save(tx);
	}

	@Test
	void testFindAllTransactions() {
		Transaction t1 = new Transaction(2L, 101L, "WITHDRAW", new BigDecimal("2000"), LocalDateTime.now(), "SUCCESS");
		Transaction t2 = new Transaction(3L, 102L, "DEPOSIT", new BigDecimal("3000"), LocalDateTime.now(), "PENDING");

		when(repo.findAll()).thenReturn(Arrays.asList(t1, t2));

		List<Transaction> transactions = repo.findAll();

		assertThat(transactions).hasSize(2);
		verify(repo).findAll();
	}

	@Test
	void testFindById() {
		Transaction tx = new Transaction(4L, 103L, "DEPOSIT", new BigDecimal("4000"), LocalDateTime.now(), "SUCCESS");

		when(repo.findById(4L)).thenReturn(Optional.of(tx));

		Optional<Transaction> found = repo.findById(4L);

		assertThat(found).isPresent();
		assertThat(found.get().getAmount()).isEqualTo(new BigDecimal("4000"));
		verify(repo).findById(4L);
	}

	@Test
	void testFindByAccountId() {
		Transaction tx = new Transaction(5L, 104L, "WITHDRAW", new BigDecimal("1500"), LocalDateTime.now(), "FAILED");

		when(repo.findByAccountId(104L)).thenReturn(List.of(tx));

		List<Transaction> transactions = repo.findByAccountId(104L);

		assertThat(transactions).isNotEmpty();
		assertThat(transactions.get(0).getStatus()).isEqualTo("FAILED");
		verify(repo).findByAccountId(104L);
	}

	@Test
	void testFindByType() {
		Transaction tx = new Transaction(6L, 105L, "DEPOSIT", new BigDecimal("2500"), LocalDateTime.now(), "SUCCESS");

		when(repo.findByType("DEPOSIT")).thenReturn(List.of(tx));

		List<Transaction> transactions = repo.findByType("DEPOSIT");

		assertThat(transactions).isNotEmpty();
		assertThat(transactions.get(0).getType()).isEqualTo("DEPOSIT");
		verify(repo).findByType("DEPOSIT");
	}

	@Test
	void testFindByStatus() {
		Transaction tx = new Transaction(7L, 106L, "WITHDRAW", new BigDecimal("1000"), LocalDateTime.now(), "PENDING");

		when(repo.findByStatus("PENDING")).thenReturn(List.of(tx));

		List<Transaction> transactions = repo.findByStatus("PENDING");

		assertThat(transactions).isNotEmpty();
		assertThat(transactions.get(0).getStatus()).isEqualTo("PENDING");
		verify(repo).findByStatus("PENDING");
	}

	@Test
	void testExistsById() {
		when(repo.existsById(8L)).thenReturn(true);

		boolean exists = repo.existsById(8L);

		assertThat(exists).isTrue();
		verify(repo).existsById(8L);
	}

	@Test
	void testCountTransactions() {
		when(repo.count()).thenReturn(5L);

		long count = repo.count();

		assertThat(count).isEqualTo(5L);
		verify(repo).count();
	}

	@Test
	void testDeleteById() {
		repo.deleteById(9L);
		verify(repo).deleteById(9L);

		when(repo.findById(9L)).thenReturn(Optional.empty());
		Optional<Transaction> found = repo.findById(9L);
		assertThat(found).isEmpty();
	}

	@Test
	void testDeleteAll() {
		repo.deleteAll();
		verify(repo).deleteAll();

		when(repo.findAll()).thenReturn(Collections.emptyList());
		List<Transaction> transactions = repo.findAll();
		assertThat(transactions).isEmpty();
	}
}
