package com.project.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import com.project.db.TransactionRepository;
import com.project.dto.TransactionRequestDTO;
import com.project.dto.TransactionResponseDTO;
import com.project.exception.TransactionNotFoundException;
import com.project.model.Transaction;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TransactionServiceTest {

	@Mock
	private TransactionRepository repo;

	@InjectMocks
	private TransactionService service;

	@Test
	void testCreateTransaction() {

		Transaction transaction = new Transaction();
		transaction.setAccountId(1L);

		when(repo.save(any(Transaction.class))).thenReturn(transaction);

		Transaction result = service.createTransaction(transaction);

		assertNotNull(result);
		assertNotNull(transaction.getTransactionDate());
		verify(repo).save(transaction);
	}

	@Test
	void testSaveFailedTransaction() {

		Transaction transaction = new Transaction();

		when(repo.save(any(Transaction.class))).thenReturn(transaction);

		Transaction result = service.saveFailedTransaction(transaction);

		assertNotNull(result);
		assertEquals("FAILED", transaction.getStatus());
		assertNotNull(transaction.getTransactionDate());

		verify(repo).save(transaction);
	}

	@Test
	void testViewAllTransactions() {

		Transaction t1 = new Transaction();
		Transaction t2 = new Transaction();

		when(repo.findAll()).thenReturn(List.of(t1, t2));

		List<Transaction> result = service.viewAllTransactions();

		assertEquals(2, result.size());
		verify(repo).findAll();
	}

	@Test
	void testDeleteTransaction() throws TransactionNotFoundException {

		when(repo.existsById(1L)).thenReturn(true);

		service.deleteTransaction(1L);

		verify(repo).deleteById(1L);
	}

	@Test
	void testDeleteTransaction_NotFound() {

		when(repo.existsById(1L)).thenReturn(false);

		assertThrows(TransactionNotFoundException.class, () -> service.deleteTransaction(1L));
	}

	@Test
	void testUpdateTransaction() throws TransactionNotFoundException {

		Transaction existing = new Transaction();
		existing.setId(1L);

		Transaction updated = new Transaction();
		updated.setAccountId(100L);
		updated.setType("DEPOSIT");
		updated.setAmount(new BigDecimal("500"));
		updated.setStatus("SUCCESS");

		TransactionRequestDTO dto = new TransactionRequestDTO();
		dto.setTransaction(updated);

		when(repo.findById(1L)).thenReturn(Optional.of(existing));

		when(repo.save(any(Transaction.class))).thenAnswer(invocation -> invocation.getArgument(0));

		Transaction result = service.updateTransaction(1L, dto);

		assertEquals("DEPOSIT", result.getType());
		assertEquals("SUCCESS", result.getStatus());

		verify(repo).save(existing);
	}

	@Test
	void testUpdateTransaction_NotFound() {

		TransactionRequestDTO dto = new TransactionRequestDTO();
		dto.setTransaction(new Transaction());

		when(repo.findById(1L)).thenReturn(Optional.empty());

		assertThrows(TransactionNotFoundException.class, () -> service.updateTransaction(1L, dto));
	}

	@Test
	void testUpdateTransaction_NullTransaction() {

		Transaction existing = new Transaction();

		TransactionRequestDTO dto = new TransactionRequestDTO();
		dto.setTransaction(null);

		when(repo.findById(1L)).thenReturn(Optional.of(existing));

		assertThrows(IllegalArgumentException.class, () -> service.updateTransaction(1L, dto));
	}

	@Test
	void testFindById() throws TransactionNotFoundException {

		Transaction transaction = new Transaction();
		transaction.setId(1L);

		when(repo.findById(1L)).thenReturn(Optional.of(transaction));

		Transaction result = service.findById(1L);

		assertEquals(1L, result.getId());
	}

	@Test
	void testFindById_NotFound() {

		when(repo.findById(1L)).thenReturn(Optional.empty());

		assertThrows(TransactionNotFoundException.class, () -> service.findById(1L));
	}

	@Test
	void testMapToResponseDto() {

		Transaction transaction = new Transaction();
		transaction.setId(1L);

		TransactionResponseDTO dto = service.mapToResponseDto(transaction);

		assertEquals(200, dto.getHttpStatusCode());
		assertEquals("Transaction fetched", dto.getMessage());
		assertEquals(transaction, dto.getTransaction());
	}

	@Test
	void testGetTransactionsByAccountId() throws TransactionNotFoundException {

		Transaction transaction = new Transaction();
		transaction.setAccountId(100L);

		when(repo.findByAccountId(100L)).thenReturn(List.of(transaction));

		List<Transaction> result = service.getTransactionsByAccountId(100L);

		assertEquals(1, result.size());
	}

	@Test
	void testGetTransactionsByAccountId_NotFound() {

		when(repo.findByAccountId(100L)).thenReturn(List.of());

		assertThrows(TransactionNotFoundException.class, () -> service.getTransactionsByAccountId(100L));
	}

	@Test
	void testGetTransactionsByType() throws TransactionNotFoundException {

		Transaction transaction = new Transaction();
		transaction.setType("DEPOSIT");

		when(repo.findByType("DEPOSIT")).thenReturn(List.of(transaction));

		List<Transaction> result = service.getTransactionsByType("DEPOSIT");

		assertEquals(1, result.size());
	}

	@Test
	void testGetTransactionsByType_NotFound() {

		when(repo.findByType("DEPOSIT")).thenReturn(List.of());

		assertThrows(TransactionNotFoundException.class, () -> service.getTransactionsByType("DEPOSIT"));
	}

	@Test
	void testGetTransactionsByStatus() throws TransactionNotFoundException {

		Transaction transaction = new Transaction();
		transaction.setStatus("SUCCESS");

		when(repo.findByStatus("SUCCESS")).thenReturn(List.of(transaction));

		List<Transaction> result = service.getTransactionsByStatus("SUCCESS");

		assertEquals(1, result.size());
	}

	@Test
	void testGetTransactionsByStatus_NotFound() {

		when(repo.findByStatus("SUCCESS")).thenReturn(List.of());

		assertThrows(TransactionNotFoundException.class, () -> service.getTransactionsByStatus("SUCCESS"));
	}
}