package com.project.ui;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.project.dto.TransactionRequestDTO;
import com.project.feign.AccountFeignClient;
import com.project.feign.dto.AccountDTO;
import com.project.model.Transaction;
import com.project.service.TransactionService;

import feign.FeignException;

@WebMvcTest(TransactionController.class)
class TransactionControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@MockitoBean
	private TransactionService service;

	@MockitoBean
	private AccountFeignClient accountFeignClient;

	@Test
	void testAddTransaction_Success() throws Exception {

		Transaction transaction = new Transaction();
		transaction.setId(1L);
		transaction.setAccountId(101L);
		transaction.setType("DEPOSIT");
		transaction.setAmount(new BigDecimal("1000"));

		TransactionRequestDTO dto = new TransactionRequestDTO();
		dto.setTransaction(transaction);

		AccountDTO accountDTO = new AccountDTO();

		when(accountFeignClient.getAccountById(101L)).thenReturn(accountDTO);

		when(service.createTransaction(any(Transaction.class))).thenReturn(transaction);

		mockMvc.perform(post("/transaction/addTransaction").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(dto))).andExpect(status().isCreated())
				.andExpect(jsonPath("$.httpStatusCode").value(201))
				.andExpect(jsonPath("$.message").value("Transaction Saved Successfully"));
	}

	@Test
	void testViewAllTransactions() throws Exception {

		Transaction t = new Transaction();
		t.setId(1L);

		when(service.viewAllTransactions()).thenReturn(List.of(t));

		mockMvc.perform(get("/transaction/viewAllTransactions")).andExpect(status().isOk())
				.andExpect(jsonPath("$.transactions.length()").value(1));
	}

	@Test
	void testViewTransaction() throws Exception {

		Transaction transaction = new Transaction();
		transaction.setId(1L);

		when(service.findById(1L)).thenReturn(transaction);

		mockMvc.perform(get("/transaction/viewTransaction/1")).andExpect(status().isOk())
				.andExpect(jsonPath("$.transaction.id").value(1))
				.andExpect(jsonPath("$.message").value("Transaction with id 1 Found"));
	}

	@Test
	void testUpdateTransaction_Success() throws Exception {

		Transaction transaction = new Transaction();
		transaction.setId(1L);
		transaction.setAccountId(101L);
		transaction.setType("DEPOSIT");
		transaction.setAmount(new BigDecimal("500"));

		TransactionRequestDTO dto = new TransactionRequestDTO();
		dto.setTransaction(transaction);

		AccountDTO accountDTO = new AccountDTO();

		when(accountFeignClient.getAccountById(101L)).thenReturn(accountDTO);

		when(service.updateTransaction(anyLong(), any(TransactionRequestDTO.class))).thenReturn(transaction);

		mockMvc.perform(put("/transaction/updateTransaction/1").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(dto))).andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("Transaction Updated Successfully"));
	}

	@Test
	void testDeleteTransaction() throws Exception {

		doNothing().when(service).deleteTransaction(1L);

		mockMvc.perform(delete("/transaction/deleteTransaction/1")).andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("Transaction with id 1 Deleted Successfully"));
	}

	@Test
	void testGetTransactionsByAccountId() throws Exception {

		Transaction transaction = new Transaction();
		transaction.setAccountId(101L);

		when(service.getTransactionsByAccountId(101L)).thenReturn(List.of(transaction));

		mockMvc.perform(get("/transaction/account/101")).andExpect(status().isOk())
				.andExpect(jsonPath("$.transactions.length()").value(1));
	}

	@Test
	void testGetTransactionsByType() throws Exception {

		Transaction transaction = new Transaction();
		transaction.setType("DEPOSIT");

		when(service.getTransactionsByType("DEPOSIT")).thenReturn(List.of(transaction));

		mockMvc.perform(get("/transaction/type/DEPOSIT")).andExpect(status().isOk())
				.andExpect(jsonPath("$.transactions.length()").value(1));
	}

	@Test
	void testGetTransactionsByStatus() throws Exception {

		Transaction transaction = new Transaction();
		transaction.setStatus("SUCCESS");

		when(service.getTransactionsByStatus("SUCCESS")).thenReturn(List.of(transaction));

		mockMvc.perform(get("/transaction/status/SUCCESS")).andExpect(status().isOk())
				.andExpect(jsonPath("$.transactions.length()").value(1));
	}

	@Test
	void testAddTransaction_AccountNotFound() throws Exception {

	    Transaction transaction = new Transaction();
	    transaction.setAccountId(101L);
	    transaction.setType("DEPOSIT");
	    transaction.setAmount(new BigDecimal("100"));

	    TransactionRequestDTO dto = new TransactionRequestDTO();
	    dto.setTransaction(transaction);

	    when(accountFeignClient.getAccountById(101L))
	            .thenThrow(Mockito.mock(FeignException.NotFound.class));

	    mockMvc.perform(post("/transaction/addTransaction")
	            .contentType(MediaType.APPLICATION_JSON)
	            .content(objectMapper.writeValueAsString(dto)))
	            .andExpect(status().isNotFound())
	            .andExpect(jsonPath("$.message").value("Account Not Found"));
	}

	@Test
	void testAddTransaction_NullTransaction() throws Exception {

		TransactionRequestDTO dto = new TransactionRequestDTO();

		mockMvc.perform(post("/transaction/addTransaction").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(dto))).andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.message").value("Transaction details are missing"));
	}

	@Test
	void testViewAllTransactions_Empty() throws Exception {

		when(service.viewAllTransactions()).thenReturn(List.of());

		mockMvc.perform(get("/transaction/viewAllTransactions")).andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("No Transactions Found"));
	}
}