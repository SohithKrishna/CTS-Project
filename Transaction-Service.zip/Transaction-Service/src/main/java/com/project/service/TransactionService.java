package com.project.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.db.TransactionRepository;
import com.project.dto.TransactionRequestDTO;
import com.project.dto.TransactionResponseDTO;
import com.project.exception.TransactionNotFoundException;
import com.project.model.Transaction;

@Service
public class TransactionService {

	@Autowired
	TransactionRepository repo;

	public Transaction createTransaction(Transaction transaction) {
		transaction.setTransactionDate(LocalDateTime.now());
		return repo.save(transaction);
	}

	public Transaction saveFailedTransaction(Transaction transaction) {
		transaction.setStatus("FAILED");
		transaction.setTransactionDate(LocalDateTime.now());
		return repo.save(transaction);
	}

	public List<Transaction> viewAllTransactions() {
		return repo.findAll();
	}

	public void deleteTransaction(Long id) throws TransactionNotFoundException {
		if (!repo.existsById(id)) {
			throw new TransactionNotFoundException("Transaction with id " + id + " Not Found");
		}
		repo.deleteById(id);
	}

	public Transaction updateTransaction(Long id, TransactionRequestDTO transactionDTO) throws TransactionNotFoundException {
		
		Transaction existingTransaction = repo.findById(id)
				.orElseThrow(() -> new TransactionNotFoundException("Transaction with id " + id + " Not Found"));
		
		Transaction updatedDetails = transactionDTO.getTransaction();

		if (updatedDetails == null) {
			throw new IllegalArgumentException("Transaction details are missing");
		}

		existingTransaction.setAccountId(updatedDetails.getAccountId());
		existingTransaction.setType(updatedDetails.getType());
		existingTransaction.setAmount(updatedDetails.getAmount());
		existingTransaction.setStatus(updatedDetails.getStatus());
		existingTransaction.setTransactionDate(LocalDateTime.now());

		return repo.save(existingTransaction);
	}

	public Transaction findById(Long id) throws TransactionNotFoundException {
		return repo.findById(id)
				.orElseThrow(() -> new TransactionNotFoundException("Transaction with id " + id + " Not Found"));
	}

	public TransactionResponseDTO mapToResponseDto(Transaction transaction) {
		TransactionResponseDTO dto = new TransactionResponseDTO();
		dto.setTransaction(transaction);
		dto.setHttpStatusCode(200);
		dto.setMessage("Transaction fetched");
		return dto;
	}

	public List<Transaction> getTransactionsByAccountId(Long accountId) throws TransactionNotFoundException {
		List<Transaction> transactions = repo.findByAccountId(accountId);
		if (transactions.isEmpty()) {
			throw new TransactionNotFoundException("No transaction found for account id: " + accountId);
		}
		return transactions;
	}

	public List<Transaction> getTransactionsByType(String type) throws TransactionNotFoundException {
		List<Transaction> transactions = repo.findByType(type);
		if (transactions.isEmpty()) {
			throw new TransactionNotFoundException("No transaction found with type: " + type);
		}
		return transactions;
	}

	public List<Transaction> getTransactionsByStatus(String status) throws TransactionNotFoundException {
		List<Transaction> transactions = repo.findByStatus(status);
		if (transactions.isEmpty()) {
			throw new TransactionNotFoundException("No transaction found with status: " + status);
		}
		return transactions;
	}
}
