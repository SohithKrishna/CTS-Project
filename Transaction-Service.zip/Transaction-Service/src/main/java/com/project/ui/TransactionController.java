package com.project.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.dto.TransactionListResponseDTO;
import com.project.dto.TransactionRequestDTO;
import com.project.dto.TransactionResponseDTO;
import com.project.exception.TransactionNotFoundException;
import com.project.feign.AccountFeignClient;
import com.project.feign.dto.AccountDTO;
import com.project.model.Transaction;
import com.project.service.TransactionService;

import feign.FeignException;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/transaction")
@Tag(name = "Transaction Controller", description = "This is a Transaction Controller")
public class TransactionController {

	@Autowired
	TransactionService service;

	@Autowired
	AccountFeignClient accountFeignClient;

	@PostMapping("/addTransaction")
	@Operation(summary = "Add Transaction")
	public ResponseEntity<TransactionResponseDTO> addTransaction(@Valid @RequestBody TransactionRequestDTO transactionDTO) {
		Transaction transaction = transactionDTO.getTransaction();
		if (transaction == null) {
			return ResponseEntity.badRequest().body(new TransactionResponseDTO(null, HttpStatus.BAD_REQUEST.value(),
					"Transaction details are missing"));
		}
		try {
			accountFeignClient.getAccountById(transaction.getAccountId());
			accountFeignClient.updateBalance(transaction.getAccountId(), transaction.getType(),
					transaction.getAmount());
			transaction.setStatus("SUCCESS");
			Transaction created = service.createTransaction(transaction);
			return ResponseEntity.status(HttpStatus.CREATED).body(
					new TransactionResponseDTO(created, HttpStatus.CREATED.value(), "Transaction Saved Successfully"));
		} catch (FeignException.NotFound ex) {
			service.saveFailedTransaction(transaction);
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.body(new TransactionResponseDTO(null, HttpStatus.NOT_FOUND.value(), "Account Not Found"));
		} catch (FeignException ex) {
			service.saveFailedTransaction(transaction);
			String response = ex.contentUTF8();
			if (response != null && response.contains("Insufficient Balance")) {
				return ResponseEntity.badRequest()
						.body(new TransactionResponseDTO(null, HttpStatus.BAD_REQUEST.value(), "Insufficient Balance"));
			}
//			if (response != null && response.contains("Amount must be greater than zero")) {
//				return ResponseEntity.badRequest().body(new TransactionResponseDTO(null, HttpStatus.BAD_REQUEST.value(),
//						"Amount must be greater than zero"));
//			}
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
					new TransactionResponseDTO(null, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Transaction Failed"));
		}
	}

	@GetMapping("/viewAllTransactions")
	@Operation(summary = "View All Transactions")
	public ResponseEntity<TransactionListResponseDTO> viewAllTransactions() {
		List<Transaction> transactions = service.viewAllTransactions();
		TransactionListResponseDTO dto = new TransactionListResponseDTO();
		dto.setHttpStatusCode(HttpStatus.OK.value());
		dto.setTransactions(transactions);
		if (transactions.isEmpty()) {
			dto.setMessage("No Transactions Found");
		} else {
			dto.setMessage(transactions.size() + " Transaction(s) fetched successfully");
		}
		return ResponseEntity.ok(dto);
	}

	@GetMapping("/viewTransaction/{id}")
	@Operation(summary = "View Transaction")
	public ResponseEntity<TransactionResponseDTO> viewTransaction(@PathVariable Long id)
			throws TransactionNotFoundException {
		Transaction transaction = service.findById(id);
		TransactionResponseDTO dto = new TransactionResponseDTO();
		dto.setHttpStatusCode(HttpStatus.OK.value());
		dto.setTransaction(transaction);
		dto.setMessage("Transaction with id " + id + " Found");
		return ResponseEntity.ok(dto);
	}

	@PutMapping("/updateTransaction/{id}")
	@Operation(summary = "Update Transaction")
	public ResponseEntity<TransactionResponseDTO> updateTransaction(@PathVariable Long id, @Valid @RequestBody TransactionRequestDTO transactionDTO) throws TransactionNotFoundException {
		Transaction transaction = transactionDTO.getTransaction();
		if (transaction == null) {
			return ResponseEntity.badRequest().body(new TransactionResponseDTO(null, HttpStatus.BAD_REQUEST.value(),
					"Transaction details are missing"));
		}
		try {
			accountFeignClient.getAccountById(transaction.getAccountId());
			accountFeignClient.updateBalance(transaction.getAccountId(), transaction.getType(),
					transaction.getAmount());
			transaction.setStatus("SUCCESS");
			Transaction updatedTransaction = service.updateTransaction(id, transactionDTO);
			return ResponseEntity.ok(new TransactionResponseDTO(updatedTransaction, HttpStatus.OK.value(),
					"Transaction Updated Successfully"));
		} catch (FeignException.NotFound ex) {
			service.saveFailedTransaction(transaction);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new TransactionResponseDTO(null,
					HttpStatus.NOT_FOUND.value(), "Account with id " + transaction.getAccountId() + " Not Found"));
		} catch (FeignException ex) {
			service.saveFailedTransaction(transaction);
			String response = ex.contentUTF8();
			if (response != null && response.contains("Insufficient Balance")) {
				return ResponseEntity.badRequest()
						.body(new TransactionResponseDTO(null, HttpStatus.BAD_REQUEST.value(), "Insufficient Balance"));
			}
			return ResponseEntity.status(HttpStatus.CONFLICT)
					.body(new TransactionResponseDTO(null, HttpStatus.CONFLICT.value(), "Transaction Failed"));
		}
	}

	@DeleteMapping("/deleteTransaction/{id}")
	@Operation(summary = "Delete Transaction")
	public ResponseEntity<TransactionResponseDTO> deleteTransaction(@PathVariable Long id)
			throws TransactionNotFoundException {
		service.deleteTransaction(id);
		TransactionResponseDTO dto = new TransactionResponseDTO();
		dto.setHttpStatusCode(HttpStatus.OK.value());
		dto.setTransaction(null);
		dto.setMessage("Transaction with id " + id + " Deleted Successfully");
		return ResponseEntity.ok(dto);
	}

	@GetMapping("/account/{accountId}")
	@Operation(summary = "Get Transactions by Account ID")
	public ResponseEntity<TransactionListResponseDTO> getTransactionsByAccountId(@PathVariable Long accountId)
			throws TransactionNotFoundException {
		List<Transaction> transactions = service.getTransactionsByAccountId(accountId);
		TransactionListResponseDTO responseDTO = new TransactionListResponseDTO();
		responseDTO.setTransactions(transactions);
		responseDTO.setHttpStatusCode(200);
		responseDTO.setMessage(transactions.size() + " transactions fetched successfully");
		return ResponseEntity.ok(responseDTO);
	}

	@GetMapping("/type/{type}")
	@Operation(summary = "Get Transactions by Type")
	public ResponseEntity<TransactionListResponseDTO> getTransactionsByType(@PathVariable String type)
			throws TransactionNotFoundException {
		List<Transaction> transactions = service.getTransactionsByType(type);
		TransactionListResponseDTO responseDTO = new TransactionListResponseDTO();
		responseDTO.setTransactions(transactions);
		responseDTO.setHttpStatusCode(200);
		responseDTO.setMessage(transactions.size() + " transactions fetched successfully");
		return ResponseEntity.ok(responseDTO);
	}

	@GetMapping("/status/{status}")
	@Operation(summary = "Get Transactions by Status")
	@Hidden
	public ResponseEntity<TransactionListResponseDTO> getTransactionsByStatus(@PathVariable String status)
			throws TransactionNotFoundException {
		List<Transaction> transactions = service.getTransactionsByStatus(status);
		TransactionListResponseDTO responseDTO = new TransactionListResponseDTO();
		responseDTO.setTransactions(transactions);
		responseDTO.setHttpStatusCode(200);
		responseDTO.setMessage(transactions.size() + " transactions fetched successfully");
		return ResponseEntity.ok(responseDTO);
	}
}
