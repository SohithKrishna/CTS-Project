package com.project.advice;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.project.dto.ErrorResponse;
import com.project.exception.TransactionNotFoundException;

import jakarta.validation.ConstraintViolationException;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(exception = TransactionNotFoundException.class)
	public ErrorResponse handleTransactionNotFoundException(Exception e) {
		ErrorResponse response = new ErrorResponse(404, e.getMessage());
		return response;
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ErrorResponse handleJsonParseError(Exception e) {
		ErrorResponse response = new ErrorResponse();
		response.setHttpStatusCode(400);
		response.setErrorMessage("Invalid request format");
		return response;
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<Map<String, Object>> handleException(Exception ex) {
		Map<String, Object> error = new HashMap<>();
		error.put("status", HttpStatus.INTERNAL_SERVER_ERROR.value());
		error.put("error", "Internal Server Error");
		error.put("message", "Something went wrong. Please try again later");
		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(error -> {
			String field = error.getField();
			if (field.contains(".")) {
				field = field.substring(field.lastIndexOf(".") + 1);
			}
			errors.put(field, error.getDefaultMessage());
		});
		return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<Map<String, String>> handleConstraintViolation(ConstraintViolationException ex) {
		Map<String, String> errors = new HashMap<>();
		ex.getConstraintViolations().forEach(violation -> {
			errors.put(violation.getPropertyPath().toString(), violation.getMessage());
		});
		return ResponseEntity.badRequest().body(errors);
	}

}
