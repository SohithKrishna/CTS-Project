package com.project.feign;

import java.math.BigDecimal;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.project.feign.dto.AccountDTO;

@FeignClient(name = "ACCOUNT-SERVICE")
public interface AccountFeignClient {
	
	@GetMapping("/account/viewAccount/{id}")
	AccountDTO getAccountById(@PathVariable("id") Long id);
	
	@PutMapping("/account/updateBalance/{id}/{type}")
	AccountDTO updateBalance(
	       @PathVariable("id") Long id,
	       @PathVariable("type") String type,
	       @RequestBody BigDecimal amount);
}
