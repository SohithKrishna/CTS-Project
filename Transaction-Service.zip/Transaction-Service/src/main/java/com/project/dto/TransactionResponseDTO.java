package com.project.dto;

import com.project.model.Transaction;

public class TransactionResponseDTO {
	
	Transaction transaction;
	int httpStatusCode;
	String message;
	
	public TransactionResponseDTO(Transaction transaction, int httpStatusCode, String message) {
		super();
		this.transaction = transaction;
		this.httpStatusCode = httpStatusCode;
		this.message = message;
	}
	
	public TransactionResponseDTO() {
		super();
	}
	
	public Transaction getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
	public int getHttpStatusCode() {
		return httpStatusCode;
	}
	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
