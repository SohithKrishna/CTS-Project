package com.project.dto;

import com.project.model.Transaction;

import jakarta.validation.Valid;

public class TransactionRequestDTO {

	@Valid
	Transaction transaction;

	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
	
}
