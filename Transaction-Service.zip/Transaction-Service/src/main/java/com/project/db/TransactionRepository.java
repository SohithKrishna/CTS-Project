package com.project.db;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.model.Transaction;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long>{
	
	List<Transaction> findByAccountId(Long accountId);
	
	List<Transaction> findByType(String type);
	
	List<Transaction> findByStatus(String status);
}
